from django.apps import AppConfig


class EmotionConfig(AppConfig):
    name = 'emotion'
