from django.apps import AppConfig


class SentimentConfig(AppConfig):
    name = 'sentiment'
